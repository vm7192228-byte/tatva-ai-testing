# Tatv AI testing — Stage 1 scope

This import is intended for the first Cloudflare testing deployment. Keep the review focused on the app shell, logo rendering, sign-in, and text chat.

## Changes in this ZIP

- Fixed the malformed `stroke-width` attribute in `public/tatv/tatv-mark.svg`; the SVG is now well-formed XML.
- Corrected the logo path documented in `README.md`.
- Added a regression test that parses the SVG as `image/svg+xml` and rejects browser parser errors.

## Chat is not declared fixed by this patch

The current Tatv Smart server route requires all of the following to produce a text answer:

1. A signed-in Supabase user session.
2. `CODEFORGE_GATEWAY_URL` configured on the Workbench server (or a separately configured fallback URL).
3. The gateway configured to trust the same Supabase Auth project and verify the user's access JWT.
4. At least one enabled chat model in the gateway's model catalog, backed by an active provider credential.

Typical API outcomes help identify the missing piece:

- `SIGN_IN_REQUIRED`: the browser has no valid signed-in session for private chat.
- `PROVIDER_NOT_CONFIGURED`: Workbench has no approved private gateway URL configured.
- `NO_PROVIDER_MODEL`: the gateway has no eligible enabled chat model, or its provider/model configuration is not usable.

Do not add gateway administrator credentials to Workbench browser variables. The Workbench forwards the signed-in user's Supabase access token to the gateway.

## Deliberately not changed in Stage 1

- Chat provider routing and gateway failover logic.
- Image generation, video generation, and image/video failover.
- Plan limits, quotas, and subscription logic.

Test the initial deployment first, collect the exact chat error/status, and then make the next narrowly scoped patch.
